Ejercicios semanas 7, 8 y 9 pa'..
