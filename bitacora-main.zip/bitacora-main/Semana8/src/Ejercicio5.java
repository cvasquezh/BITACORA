import java.util.*;
public class Ejercicio5 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Ingresa el la cantidad de estudiantes: ");
		int n=sc.nextInt();
		int [][]matriz1=new int [4][n];
        //No hemos visto menús hasta este momento
	}

}
