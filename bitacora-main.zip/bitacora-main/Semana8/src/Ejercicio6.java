
public class Ejercicio6 {

	public static void main(String[] args) {
		//No hemos visto menús todavía
	}

}
